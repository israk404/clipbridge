ClipBridge 2.0.1 for Windows
=================================

1. Keep this whole folder together (for example in Documents\ClipBridge).
2. Double-click ClipBridge.exe.
3. When Windows Firewall asks, tick "Private networks" and click Allow
   (it may show as "pythonw.exe" — that's ClipBridge's built-in runtime).

If SmartScreen says "Windows protected your PC": More info -> Run anyway.

Setup guide: https://github.com/israk404/clipbridge/blob/main/docs/SETUP.md
