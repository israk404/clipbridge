"""ClipBridge for Windows."""
__version__ = "2.0.1"
